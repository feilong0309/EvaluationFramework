#pragma once
#include "common/cmd_options.h"

#include "common/graph/dot_parser.h"

namespace mapsets {

void BuildTrees(DotGraph& g);

} // namespace mapsets

