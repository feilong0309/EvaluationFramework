import os
import time

if __name__ == "__main__":

    #node_list = ['102','181','794']
    node_list = []
    
    separator = '\t'
    
    print "start to collect nodes..."
    source = open('community_v1.dat', 'r')
    for line in source:
        node_id, cluster = line[:-1].split(separator)
        if node_id not in node_list:
            node_list.append(node_id)
    source.close()
    print "nodes collection completed."
    
    print "start to create subgraph..."
    old_graph = open('network_v1.dat', 'r')
    new_graph = open('network_v1_subgraph_speed_up.dat', 'w')
	
    last_source_id = 0;
    flag_last_source_id_exists_in_node_list = 0; #0: not exitst  1: exists
	
    for line in old_graph:
        source_id, destination_id = line[:-1].split(separator)
		    #assuming all the nodes are ranked by value from "small" to "big"
        if (source_id != last_source_id): #Now we turn to a bigger value stage
            
            print "now we turn to source_id = %s" %(source_id)
           
            last_source_id = source_id #record the value for this stage
            if (source_id in node_list): #the source_id is in node_list, so we should check its destination_id
                flag_last_source_id_exists_in_node_list = 1; #turn the flag to 1 so that we know the source_id exists in node_list when we check the flag = 1
                if (destination_id in node_list):
                    #print line
                    new_graph.write(line)
            else:
                #print "  this source_id is not in node_list"
                flag_last_source_id_exists_in_node_list = 0; #turn the flag to 0 so that we can ignore the line with the flag = 1
		
        else: #the source_id in this line is the same as the one in last line
            if (flag_last_source_id_exists_in_node_list == 1): #the source_id exists in node list, so we should check its destination_id
                if (destination_id in destination_id in node_list): #the destination_id also exists in node_list, we should record this line in subset
                    #print line
                    new_graph.write(line)
	
		
		
    print "subgraph creation completed."
    
    old_graph.close()
    new_graph.close()