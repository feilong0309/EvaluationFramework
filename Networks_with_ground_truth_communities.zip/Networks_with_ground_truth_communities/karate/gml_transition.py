import networkx as nx
import os
import time

#please install networkx-1.9.1 first http://stackoverflow.com/questions/31946029/networkx-read-gml-error-networkx-exception-networkxerror-cannot-tokenize-ugra

def generate_network_dat(filename, G, seperator):
    
    fp = open(filename + '.network.dat', 'w')
    for i in G.edges():
        source_id = i[0]
        destination_id = i[1]
        line_str = str(source_id) + seperator + str(destination_id )+ '\n' 
        fp.write(line_str)

    fp.close()
    
def generate_community_dat(filename, G, seperator):

    community_name_list = []
    community_id_list = []

    fp = open(filename + '.community.dat', 'w')
   
    node_id_list = G.nodes()
    min_id = node_id_list[0]

    for i in range(min_id, G.number_of_nodes()):
        node_id = G.node[i]['id']
        community_name = G.node[i]['value']
        
        if isinstance(community_name, int):
            community_id = community_name
        else:

            j = 0 

            while j < len(community_name_list):
                if community_name_list[j] == community_name:
                    community_id  = j
                    break;
                j = j + 1
                         
            if (j == len(community_name_list)):
                community_name_list.append(community_name)
                community_id = j
            
        line_str = str(node_id) + seperator + str(community_id )+ '\n'
        fp.write(line_str)

    fp.close()
 
if __name__ == '__main__':
    
    seperator = '\t'

    rootdir = "./";   
    for parent, dirnames, filenames in os.walk(rootdir):
        for filename in filenames:
            split_filename = filename.split('.');
            if split_filename[len(split_filename) - 1] == 'gml' :
                full_name = os.path.join(parent, filename);
                print full_name
                G = nx.read_gml(full_name)
                generate_network_dat(full_name, G, seperator)
                generate_community_dat(full_name, G, seperator)

    #filename = 'polblogs/polblogs.gml'
    #filename = 'polbooks/polbooks.gml'
    #filename = 'football/football.gml'

    #G = nx.read_gml(filename)
    #print 'generate_network_dat:'
    #generate_network_dat(filename, G, seperator)
    #print 'generate_community_dat:'
    #generate_community_dat(filename, G, seperator)

    #for i in range(0, G.number_of_nodes()):
    #    print G.node[i]

    #print G.number_of_nodes()
    #print G.node[0]
